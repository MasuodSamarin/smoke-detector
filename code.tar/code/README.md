
this is my avr project. it's about to drive a mq2 smoke sensor and show the result on the lcd.
i use an avr atmega32 microController in this project and use a 4x4 keypad for get the user commands.


component:
    1. avr atmega32
    2. lcd 16x2 alphanum
    3. 4x4 standard keypad
    4. relay to support 220ac load
    5. buzzer 
    6. mq2 smoke sensor
    7. lm35 temperatur sensor


