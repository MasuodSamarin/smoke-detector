

#ifndef MY_TEST_H_
#define MY_TEST_H_

void keypad_test(void);
void mq2_test(void);
void output_test(void);
void lm35_test(void);
void keypad_talk_back(void);

#endif
